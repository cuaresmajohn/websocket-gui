-- Treatment Tables --
CREATE TABLE TREATMENT_STATUS (
    Id          smallint identity primary key,
    Status      varchar(30) not null
    );

CREATE TABLE TREATMENT (
    Id                  integer identity primary key,
    Code    	        varchar(30) unique not null,
    Name                varchar(80) not null,
    StatusId            smallint not null,
    LastRunBy           varchar(80),
    LastRunDate         timestamp,
    LastModifiedBy      varchar(80),
    LastModifiedDate    timestamp,
    IsEnabled           bit
    );

CREATE TABLE TREATMENT_CHAIN (
    TreatmentId     integer identity primary key,
    ChainCode       varchar(30) not null,
    ChainName       varchar(80) not null,
    TreatmentOrder  integer not null,
    LastRunBy       varchar(80),
    LastRunDate     timestamp
    );

CREATE TABLE TREATMENT_CONFIG (
    TreatmentId     integer identity primary key,
    ExecTime        timestamp,
    Dependencies    varchar(max),
    Command         varchar(2014) not null
    );

ALTER TABLE TREATMENT ADD FOREIGN KEY (StatusId) REFERENCES TREATMENT_STATUS(Id);
ALTER TABLE TREATMENT_CHAIN ADD FOREIGN KEY (TreatmentId) REFERENCES TREATMENT(Id);
ALTER TABLE TREATMENT_CONFIG ADD FOREIGN KEY (TreatmentId) REFERENCES TREATMENT(Id);
