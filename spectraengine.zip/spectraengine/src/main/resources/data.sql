INSERT INTO TREATMENT_STATUS (Id, Status) VALUES
    (1, 'Not Started'),
    (2, 'Running'),
    (3, 'Failed'),
    (4, 'Completed');

INSERT INTO TREATMENT (Id, Code, Name, StatusId, LastRunBy, LastRunDate, LastModifiedBy, LastModifiedDate, IsEnabled) VALUES
    (1, 'T_ONE', 'Treatment To Run Hello World', 1, null, null, null, null, 1 ),
    (2, 'T_TWO', 'Treatment To Run End of the World', 1, null, null, null, null, 0),
    (3, 'T_THREE', 'Treatment To Run Nothing', 1, null, null, null, null, 1);

INSERT INTO TREATMENT_CHAIN (TreatmentId, ChainCode, ChainName, TreatmentOrder, LastRunBy, LastRunDate) VALUES
    (1, 'SPECTRA', 'Testing', 1, null, null),
    (2, 'SPECTRA', 'Testing', 2, null, null),
    (3, 'LTK', 'Testing Two', 1, null, null);

INSERT INTO TREATMENT_CONFIG (TreatmentId, Command, ExecTime, Dependencies) VALUES
    (1, 'D:\\Eclipse\\test.bat', '2020-01-01 02:00:00', null),
    (2, 'D:\\Eclipse\\End.bat', '2020-01-01 02:00:00', null),
    (3, 'D:\\Eclipse\\End.bat', null, null);
