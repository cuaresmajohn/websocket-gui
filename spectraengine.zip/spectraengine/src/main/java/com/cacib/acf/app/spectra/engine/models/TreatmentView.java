package com.cacib.acf.app.spectra.engine.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreatmentView {
    private long id;
    private String code;
    private String name;
    private short status;
    private boolean isEnabled;
    private String command;
    private LocalDateTime execTime;
    private String chainCode;
    private int order;
}
