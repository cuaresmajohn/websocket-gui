package com.cacib.acf.app.spectra.engine.repository;

import com.cacib.acf.app.spectra.engine.repository.models.TreatmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TreatmentStatusRepository extends JpaRepository<TreatmentStatus, Long> {
}
