package com.cacib.acf.app.spectra.engine.services;

import com.cacib.acf.app.spectra.engine.models.TreatmentView;

import java.util.List;

public interface TreatmentService {

    List<TreatmentView> getAllTreatmentsView();

    boolean executeCommand(TreatmentView treatmentView);

    void save(TreatmentView treatment);
}
