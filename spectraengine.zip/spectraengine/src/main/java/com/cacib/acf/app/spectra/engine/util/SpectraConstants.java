package com.cacib.acf.app.spectra.engine.util;

public class SpectraConstants {

    private SpectraConstants() {

    }

    public static final short STATUS_NOT_STARTED = 1;

    public static final short STATUS_RUNNING = 2;

    public static final short STATUS_COMPLETED = 3;

    public static final short STATUS_FAILED = 4;

}
