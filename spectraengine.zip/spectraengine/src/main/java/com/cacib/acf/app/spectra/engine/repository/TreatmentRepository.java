package com.cacib.acf.app.spectra.engine.repository;

import com.cacib.acf.app.spectra.engine.repository.models.Treatment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TreatmentRepository extends JpaRepository<Treatment, Long> {
}
