package com.cacib.acf.app.spectra.engine.repository.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "TREATMENT_STATUS")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreatmentStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Short id;

    private String status;
}
