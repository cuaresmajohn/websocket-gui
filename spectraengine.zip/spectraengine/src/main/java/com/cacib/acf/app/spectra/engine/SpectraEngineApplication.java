package com.cacib.acf.app.spectra.engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class SpectraEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpectraEngineApplication.class, args);
	}

}
