package com.cacib.acf.app.spectra.engine.tasks;

import com.cacib.acf.app.spectra.engine.models.TreatmentView;
import com.cacib.acf.app.spectra.engine.services.TreatmentService;
import com.cacib.acf.app.spectra.engine.util.SpectraConstants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
@Slf4j
public class TreatmentTasks {

    private TreatmentService service;
    private SimpMessagingTemplate simpMessagingTemplate;

    @Scheduled(fixedRate = 60000, initialDelay = 6000)
    public void scheduleTaskWithInitialDelay() {
        List<TreatmentView> treatments = service.getAllTreatmentsView();
        log.info("Treatments - {}", treatments);

        LocalDateTime now = LocalDateTime.now();

        for (TreatmentView treatment : treatments) {
            LocalDateTime executionTime = treatment.getExecTime();
            if (executionTime == null || !treatment.isEnabled()) {
                continue;
            }

            if (now.isAfter(executionTime) && treatment.getStatus() != SpectraConstants.STATUS_RUNNING) {
                Thread newThread = new Thread(() -> {
                    processTreatment(treatment, now, treatments);
                });
                newThread.start();
            }
        }
    }

    private void processTreatment(TreatmentView treatment, LocalDateTime executionTime, List<TreatmentView> treatments) {
        log.info("Processing {} treatment.", treatment.getCode());
        updateRelatedTreatments(treatment, treatments);

        boolean isSuccessful = service.executeCommand(treatment);

        if (isSuccessful) {
            treatment.setStatus(SpectraConstants.STATUS_COMPLETED);
            /* Updates time to next hour/day execution */
            treatment.setExecTime(executionTime.plusHours(1));
            updateNextTreatment(treatment, treatments);
        } else {
            treatment.setStatus(SpectraConstants.STATUS_FAILED);
            /* Should retry or do something else? */
            treatment.setExecTime(executionTime.plusMinutes(5));
        }

        log.info("Treatment process for {} isSuccessful = {}", treatment.getCode(), isSuccessful);
        treatment.setEnabled(true);
        service.save(treatment);
        sendTreatmentStatus(treatment);
    }

    private void updateNextTreatment(TreatmentView treatment, List<TreatmentView> treatments) {
        int nextTreatmentOrder = treatment.getOrder() + 1;
        List<TreatmentView> treatmentsToUpdate = treatments.stream().filter(x -> x.getChainCode()
                .equalsIgnoreCase(treatment.getChainCode()) && x.getOrder() == nextTreatmentOrder).collect(Collectors.toList());

        treatmentsToUpdate.stream().forEach( treatmentView -> {
            log.info("Enabling {} treatment.", treatment.getCode());
            treatmentView.setEnabled(true);
            service.save(treatmentView);
        });
    }

    //Refactor Method Name
    private void updateRelatedTreatments(TreatmentView treatment, List<TreatmentView> treatments) {
        // Updates treatment to running
        treatment.setStatus(SpectraConstants.STATUS_RUNNING);
        treatment.setEnabled(false);

        // TODO: Might need to change to publish whole treatment chain status update
        sendTreatmentStatus(treatment);
        service.save(treatment);

        List<TreatmentView> treatmentsToUpdate = treatments.stream().filter(x -> x.getChainCode()
                .equalsIgnoreCase(treatment.getChainCode()) && !x.getCode().equalsIgnoreCase(treatment.getCode())).collect(Collectors.toList());

        // Updates related treatment status
        treatmentsToUpdate.stream().forEach( treatmentView -> {
            log.info("Disabling {} treatment.", treatment.getCode());
            treatmentView.setEnabled(false);
            if (treatmentView.getOrder() > treatment.getOrder()) {
                // Reset treatments greater than the current treatment
                treatmentView.setStatus(SpectraConstants.STATUS_NOT_STARTED);
            }
            service.save(treatmentView);
        });

    }

    private void sendTreatmentStatus(TreatmentView treatment) {
        log.info("Publishing Treatment : {}", treatment);
        simpMessagingTemplate.convertAndSend("/topic/treatment/status", treatment);
    }

//    @Scheduled(cron = "0 * * * * ?")
//    public void scheduleTaskWithCronExpression() {
//        logger.info("Cron Task :: Execution Time - {}", dateTimeFormatter.format(LocalDateTime.now()));
//    }

}
