package com.cacib.acf.app.spectra.engine.repository.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TREATMENT")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Treatment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String code;

	private String name;

	@Column(name="STATUSID")
	private Short statusId;

	@Column(name="LASTRUNBY")
	private String lastRunBy;

	@Column(name="LASTRUNDATE")
	private LocalDateTime lastRunDate;

	@Column(name="LASTMODIFIEDBY")
	private String lastModifiedBy;

	@Column(name="LASTMODIFIEDDATE")
	private LocalDateTime lastModifiedDate;

	@Column(name="ISENABLED")
	private Boolean isEnabled;

	@OneToOne(mappedBy = "treatment", cascade = CascadeType.ALL)
	private TreatmentConfig treatmentConfig;

	@OneToOne(mappedBy = "treatment", cascade = CascadeType.ALL)
	private TreatmentChain treatmentChain;
}
