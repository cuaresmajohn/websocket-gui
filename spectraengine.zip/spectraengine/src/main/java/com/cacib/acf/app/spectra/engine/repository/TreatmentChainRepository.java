package com.cacib.acf.app.spectra.engine.repository;

import com.cacib.acf.app.spectra.engine.repository.models.TreatmentChain;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TreatmentChainRepository extends JpaRepository<TreatmentChain, Long> {
}
