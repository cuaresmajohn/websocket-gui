package com.cacib.acf.app.spectra.engine.controller;

import com.cacib.acf.app.spectra.engine.models.TreatmentView;
import com.cacib.acf.app.spectra.engine.services.TreatmentService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@AllArgsConstructor
public class TreatmentController {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private TreatmentService service;

    @SubscribeMapping("/treatment/get")
    public List<TreatmentView> findAll() {
        return service.getAllTreatmentsView();
    }

    @MessageMapping("/treatment/run")
    public void treatmentRun() {
        //service.runTreatment();
    }

}
