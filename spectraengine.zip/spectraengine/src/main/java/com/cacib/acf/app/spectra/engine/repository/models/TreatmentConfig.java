package com.cacib.acf.app.spectra.engine.repository.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TREATMENT_CONFIG")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreatmentConfig {
	@Id
	@Column(name = "TREATMENTID")
	private Long treatmentId;

	private String command;

	@Column(name = "EXECTIME")
	private LocalDateTime execTime;

	private String dependencies;

	@OneToOne (cascade=CascadeType.ALL)
	@JoinColumn(name="TREATMENTID")
	private Treatment treatment;
}
