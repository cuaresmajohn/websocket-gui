package com.cacib.acf.app.spectra.engine.repository.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TREATMENT_CHAIN")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreatmentChain {
    @Id
    @Column(name = "TREATMENTID")
    private Long treatmentId;

    @Column(name="CHAINCODE")
    private String chainCode;

    @Column(name="TREATMENTORDER")
    private Integer treatmentOrder;

    @Column(name="LASTRUNBY")
    private String lastRunBy;

    @Column(name="LASTRUNDATE")
    private LocalDateTime lastRunDate;

    @OneToOne (cascade=CascadeType.ALL)
    @JoinColumn(name="TREATMENTID")
    private Treatment treatment;

}
