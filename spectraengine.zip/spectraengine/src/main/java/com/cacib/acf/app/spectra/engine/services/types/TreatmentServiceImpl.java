package com.cacib.acf.app.spectra.engine.services.types;

import com.cacib.acf.app.spectra.engine.models.TreatmentView;
import com.cacib.acf.app.spectra.engine.repository.TreatmentRepository;
import com.cacib.acf.app.spectra.engine.repository.models.Treatment;
import com.cacib.acf.app.spectra.engine.services.TreatmentService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class TreatmentServiceImpl implements TreatmentService {

	private TreatmentRepository repository;

    @Override
    public List<TreatmentView> getAllTreatmentsView() {
        return repository.findAll().stream().map(this::getTreatmentView).collect(Collectors.toList());
    }
    // Can Add filter/columns to separate Jobs Run By Minute and By Hours

    @Override
    public boolean executeCommand(TreatmentView treatment) {
		log.info("Treatment - {} ", treatment.getName());
        String command = treatment.getCommand();
        log.info("Running - {} ", command);
        ProcessBuilder processBuilder = new ProcessBuilder(command);
        try {
            Process process = processBuilder.start();

            StringBuilder output = new StringBuilder();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            int exitVal = process.waitFor();

            log.info("Batch Execution - {}", output );

            if (exitVal == 0) {
                log.info("Batch Execution Successful");
                return true;
        }

        log.info("Batch Execution Failed");

        } catch (IOException e) {
            log.error("IOException - Error: {}", e.getMessage());
        } catch (InterruptedException e) {
            log.error("InterruptedException - Error: {}", e.getMessage());
            /* Fix this error */
        }
        return false;
    }

    @Override
    public void save(TreatmentView treatmentView) {
        Optional<Treatment> treatment;
        treatment = repository.findById(treatmentView.getId());
        if (treatment.isPresent()) {
            treatment.get().setStatusId(treatmentView.getStatus());
            treatment.get().setIsEnabled(treatmentView.isEnabled());
            treatment.get().getTreatmentConfig().setExecTime(treatmentView.getExecTime());
            repository.save(treatment.get());
        }
    }

    private TreatmentView getTreatmentView(Treatment treatment) {
        return new TreatmentView(
                treatment.getId(),
                treatment.getCode(),
                treatment.getName(),
                treatment.getStatusId(),
                treatment.getIsEnabled(),
                treatment.getTreatmentConfig().getCommand(),
                treatment.getTreatmentConfig().getExecTime(),
                treatment.getTreatmentChain().getChainCode(),
                treatment.getTreatmentChain().getTreatmentOrder()
        );
    }
}
