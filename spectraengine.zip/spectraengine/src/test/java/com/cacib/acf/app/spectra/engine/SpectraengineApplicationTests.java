package com.cacib.acf.app.spectra.engine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpectraengineApplicationTests {

	@Test
	void contextLoads() {
	}

}
